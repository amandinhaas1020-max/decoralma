
const API='/api/site-data';
const LOGIN_USER='admin';
const LOGIN_PASS='decoralma123';
let dados=null;

function entrar(){
  const u=document.getElementById('usuario').value.trim();
  const s=document.getElementById('senha').value.trim();
  if(u===LOGIN_USER && s===LOGIN_PASS){
    sessionStorage.setItem('decoralmaAdmin','ok');
    document.getElementById('login').style.display='none';
    document.getElementById('painel').style.display='grid';
    carregar();
  }else document.getElementById('erroLogin').innerText='Usuário ou senha incorretos.';
}
function sair(){sessionStorage.removeItem('decoralmaAdmin');location.reload();}
if(sessionStorage.getItem('decoralmaAdmin')==='ok'){setTimeout(()=>{document.getElementById('login').style.display='none';document.getElementById('painel').style.display='grid';carregar();},50)}

function abrirAba(id){
  document.querySelectorAll('.aba').forEach(a=>a.style.display='none');
  document.getElementById(id).style.display='block';
  const nomes={dashboard:'Visão geral',produtos:'Produtos',colecoes:'Nossos destaques',acessorios:'Acessórios',inspire:'Inspire-se',capa:'Capa'};
  document.getElementById('tituloAba').innerText=nomes[id]||id;
  render();
}
async function carregar(){
  const r=await fetch(API);
  dados=await r.json();
  preencherCapa();
  render();
}
async function salvar(){
  await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(dados)});
  render();
}
function img(src){return src||'https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=700&q=80'}
function render(){
  if(!dados) return;
  document.getElementById('qtdProdutos').innerText=dados.produtos.length;
  document.getElementById('qtdColecoes').innerText=dados.colecoes.length;
  document.getElementById('qtdAcessorios').innerText=dados.acessorios.length;
  document.getElementById('qtdInspire').innerText=dados.inspire.length;
  document.getElementById('prodColecao').innerHTML=dados.colecoes.map((c,i)=>`<option value="${i}">${c.nome}</option>`).join('');
  listaProdutos.innerHTML=dados.produtos.map((p,i)=>`<div class="item"><img src="${img(p.img)}"><div><b>${p.nome}</b><small>${p.preco} • ${(dados.colecoes[p.colecao]||{}).nome||'Coleção'}</small></div><div><button onclick="editarProduto(${i})">Editar</button><button class="danger" onclick="removerProduto(${i})">Remover</button></div></div>`).join('');
  listaColecoes.innerHTML=dados.colecoes.map((c,i)=>`<div class="item"><img src="${img(c.img)}"><div><b>${c.nome}</b><small>${c.desc||''}</small></div><div><button onclick="editarColecao(${i})">Editar</button><button class="danger" onclick="removerColecao(${i})">Remover</button></div></div>`).join('');
  listaAcessorios.innerHTML=dados.acessorios.map((p,i)=>`<div class="item"><img src="${img(p.img)}"><div><b>${p.nome}</b><small>${p.preco}</small></div><div><button onclick="editarAcessorio(${i})">Editar</button><button class="danger" onclick="removerAcessorio(${i})">Remover</button></div></div>`).join('');
  listaInspire.innerHTML=dados.inspire.map((p,i)=>`<div class="item"><img src="${img(p)}"><div><button class="danger" onclick="removerInspire(${i})">Remover</button></div></div>`).join('');
}
function limpar(ids){ids.forEach(id=>document.getElementById(id).value='')}

async function adicionarProduto(){dados.produtos.push({nome:prodNome.value||'Produto',preco:prodPreco.value||'R$ 0,00',img:prodImg.value||'',colecao:Number(prodColecao.value||0)});limpar(['prodNome','prodPreco','prodImg']);await salvar()}
async function editarProduto(i){let p=dados.produtos[i]; let n=prompt('Nome:',p.nome); if(n===null)return; let pr=prompt('Preço:',p.preco); if(pr===null)return; let im=prompt('Imagem:',p.img); if(im===null)return; p.nome=n;p.preco=pr;p.img=im;await salvar()}
async function removerProduto(i){if(confirm('Remover produto?')){dados.produtos.splice(i,1);await salvar()}}

async function adicionarColecao(){dados.colecoes.push({nome:colNome.value||'Destaque',icone:colIcone.value||'❧',img:colImg.value||'',desc:colDesc.value||''});limpar(['colNome','colIcone','colImg','colDesc']);await salvar()}
async function editarColecao(i){let c=dados.colecoes[i]; let n=prompt('Nome:',c.nome); if(n===null)return; let d=prompt('Descrição:',c.desc||''); if(d===null)return; let im=prompt('Imagem:',c.img||''); if(im===null)return; c.nome=n;c.desc=d;c.img=im;await salvar()}
async function removerColecao(i){if(confirm('Remover destaque?')){dados.colecoes.splice(i,1);await salvar()}}

async function adicionarAcessorio(){dados.acessorios.push({nome:aceNome.value||'Acessório',preco:acePreco.value||'R$ 0,00',img:aceImg.value||''});limpar(['aceNome','acePreco','aceImg']);await salvar()}
async function editarAcessorio(i){let p=dados.acessorios[i]; let n=prompt('Nome:',p.nome); if(n===null)return; let pr=prompt('Preço:',p.preco); if(pr===null)return; let im=prompt('Imagem:',p.img); if(im===null)return; p.nome=n;p.preco=pr;p.img=im;await salvar()}
async function removerAcessorio(i){if(confirm('Remover acessório?')){dados.acessorios.splice(i,1);await salvar()}}

async function adicionarInspire(){if(!inspImg.value)return alert('Coloque uma imagem');dados.inspire.push(inspImg.value);limpar(['inspImg']);await salvar()}
async function removerInspire(i){dados.inspire.splice(i,1);await salvar()}

function preencherCapa(){heroTitulo.value=(dados.hero.titulo||'').replace(/<br\/?>\/gi,'\n');heroTexto.value=dados.hero.texto||'';heroImg.value=dados.hero.img||''}
async function salvarCapa(){dados.hero.titulo=(heroTitulo.value||'').replace(/\n/g,'<br/>');dados.hero.texto=heroTexto.value||'';dados.hero.img=heroImg.value||'';await salvar();alert('Capa salva!')}
