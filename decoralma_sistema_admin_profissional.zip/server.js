
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({limit:'10mb'}));
app.use(express.static(path.join(__dirname, 'public')));

const DB = path.join(__dirname, 'data.json');

function readData(){
  if(!fs.existsSync(DB)) return {};
  return JSON.parse(fs.readFileSync(DB,'utf8'));
}
function writeData(data){
  fs.writeFileSync(DB, JSON.stringify(data,null,2), 'utf8');
}

app.get('/api/site-data', (req,res)=>res.json(readData()));
app.post('/api/site-data', (req,res)=>{
  writeData(req.body);
  res.json({ok:true});
});

app.get('/admin', (req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Decoralma admin rodando na porta '+PORT));
